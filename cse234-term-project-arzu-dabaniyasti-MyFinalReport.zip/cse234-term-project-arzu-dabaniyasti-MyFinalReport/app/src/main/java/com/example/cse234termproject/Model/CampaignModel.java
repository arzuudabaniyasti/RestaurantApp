
package com.example.cse234termproject.Model;

public class CampaignModel {
    private String image;
    public CampaignModel(){
    }
    public CampaignModel(String image) {
        this.image = image;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }
}